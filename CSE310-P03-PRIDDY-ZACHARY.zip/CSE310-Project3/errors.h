/******************************************************************************
* errors.h
* 
* Date:   2013-11-24 19:33:38
*
* Zachary Priddy
* zpriddy@asu.edu
* www.zpriddy.com
*
* DESCRIPTION:
*
*
******************************************************************************/
#include <fstream>




using namespace std;

#ifndef ERRORS_H_
#define ERRORS_H_

// Prototypes
void error(int, string);

#endif